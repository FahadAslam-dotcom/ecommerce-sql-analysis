-- E-commerce SQL Analysis | Validation Checks
USE ecommerce_portfolio;

-- Each query should return zero rows unless the comment says otherwise.

-- Customers without an email (should return zero rows)
SELECT customer_id
FROM customers
WHERE email IS NULL OR email = '';

-- Orphaned orders (foreign keys should prevent these)
SELECT o.order_id
FROM orders o
LEFT JOIN customers c ON c.customer_id = o.customer_id
WHERE c.customer_id IS NULL;

-- Orphaned order items
SELECT oi.order_item_id
FROM order_items oi
LEFT JOIN orders o ON o.order_id = oi.order_id
LEFT JOIN products p ON p.product_id = oi.product_id
WHERE o.order_id IS NULL OR p.product_id IS NULL;

-- Invalid quantity or price
SELECT order_item_id, quantity
FROM order_items
WHERE quantity <= 0;

SELECT product_id, price, stock
FROM products
WHERE price < 0 OR stock < 0;

-- Order status distribution (expected: Delivered 15, Cancelled 3, Pending 2)
SELECT order_status, COUNT(*) AS order_count
FROM orders
GROUP BY order_status
ORDER BY order_status;
