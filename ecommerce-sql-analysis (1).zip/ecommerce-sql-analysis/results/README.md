# Query Results

Save screenshots or exported result files here after running the SQL queries in MySQL Workbench.

Do not add invented results. Include the query number, a short description, and the actual output from your own MySQL run.
