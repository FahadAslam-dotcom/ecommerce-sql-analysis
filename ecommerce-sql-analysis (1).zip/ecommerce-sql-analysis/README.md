# E-commerce SQL Analysis

An intermediate-level MySQL portfolio project that models a small e-commerce store and answers business questions using relational SQL queries.

## Project objectives

- Design a relational database with customers, products, orders, order items, and payments.
- Use primary keys, foreign keys, unique constraints, `NOT NULL`, and `CHECK` constraints.
- Analyze delivered-order revenue, product performance, customer spend, order status, cancellation rate, and payment methods.
- Practice data-quality checks and write readable, reusable SQL.

## Tech stack

- MySQL 8.0.16+ (for enforced `CHECK` constraints)
- MySQL Workbench or another MySQL client
- SQL

## Repository structure

```text
ecommerce-sql-analysis/
├── README.md
├── .gitignore
├── sql/
│   ├── 01_schema.sql
│   ├── 02_sample_data.sql
│   ├── 03_analysis_queries.sql
│   └── 04_validation_checks.sql
└── results/
    └── README.md
```

## Database schema

- `customers`: customer contact and signup information
- `products`: product category, price, and stock
- `orders`: customer, date, and status
- `order_items`: products and quantities in each order
- `payments`: payment method, amount, and date

Relationships:
- One customer can place many orders.
- An order can contain multiple order items.
- Each order item references one product.
- An order can have payment records.

## How to run

Use a **test database** and run each script in order in MySQL Workbench:

1. Open and execute `sql/01_schema.sql`.
2. Execute `sql/02_sample_data.sql` once.
3. Execute `sql/03_analysis_queries.sql` to explore the analysis.
4. Execute `sql/04_validation_checks.sql` to review data quality.

The scripts create/use a separate database named `ecommerce_portfolio`; they do not use the original `Aslane` database. Run the sample-data script only once on a fresh project database unless you reset the tables first.

## Business questions answered

1. What is the revenue from delivered orders?
2. Which products generate the most estimated revenue?
3. Which customers have spent the most on delivered orders?
4. Which products sell the most units in delivered orders?
5. How many orders are delivered, pending, or cancelled?
6. What is the cancellation rate?
7. Which product categories contribute the most estimated revenue?
8. Which payment methods account for the most payment value?
9. How do order counts change by date?
10. Which products have low stock?
11. Which orders have no payment record?
12. Which non-delivered orders still have line items?

## Important assumptions and limitations

- The data is small, synthetic sample data for practice; it is not evidence of real business performance.
- Product revenue is estimated using `order_items.quantity * products.price`. A production database would usually store the price paid per item at the time of purchase, because the current product price can change.
- Payment totals and item-level revenue are different measures. Discounts, refunds, shipping, taxes, and partial payments are not modeled here.
- The low-stock threshold of 50 units is an example and should be adjusted to business requirements.
- The SQL scripts are prepared for MySQL 8.0.16+. Run them in your own MySQL environment and verify the results before describing the project as tested.

## Skills demonstrated

Relational database design, joins, aggregate functions, `GROUP BY`, sorting, conditional aggregation, data validation, constraints, and business-oriented SQL analysis.

## Future improvements

- Add a stored order-item price to preserve historical sales values.
- Model refunds, discounts, and shipping fees.
- Add more realistic multi-month sample data for trend analysis.
- Add an ER diagram and screenshots of query outputs.
- Add indexes based on `EXPLAIN` results and actual query performance.

## Author

Add your name and LinkedIn profile here before publishing.
