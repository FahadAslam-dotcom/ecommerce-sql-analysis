-- E-commerce SQL Analysis | Business Questions
USE ecommerce_portfolio;

-- 1. Revenue from payments linked to delivered orders
SELECT COALESCE(SUM(p.amount), 0) AS delivered_order_revenue
FROM payments p
JOIN orders o ON o.order_id = p.order_id
WHERE o.order_status = 'Delivered';

-- 2. Revenue by product from delivered orders
-- Note: this estimates item revenue using the current products.price.
SELECT pr.product_id, pr.product_name,
       SUM(oi.quantity * pr.price) AS product_revenue
FROM order_items oi
JOIN products pr ON pr.product_id = oi.product_id
JOIN orders o ON o.order_id = oi.order_id
WHERE o.order_status = 'Delivered'
GROUP BY pr.product_id, pr.product_name
ORDER BY product_revenue DESC;

-- 3. Top customers by delivered-order spend
SELECT c.customer_id, c.name,
       SUM(p.amount) AS total_spent
FROM customers c
JOIN orders o ON o.customer_id = c.customer_id
JOIN payments p ON p.order_id = o.order_id
WHERE o.order_status = 'Delivered'
GROUP BY c.customer_id, c.name
ORDER BY total_spent DESC;

-- 4. Best-selling products by units in delivered orders
SELECT pr.product_id, pr.product_name,
       SUM(oi.quantity) AS units_sold
FROM order_items oi
JOIN products pr ON pr.product_id = oi.product_id
JOIN orders o ON o.order_id = oi.order_id
WHERE o.order_status = 'Delivered'
GROUP BY pr.product_id, pr.product_name
ORDER BY units_sold DESC, pr.product_name;

-- 5. Order counts by status
SELECT order_status, COUNT(*) AS order_count
FROM orders
GROUP BY order_status
ORDER BY order_count DESC;

-- 6. Cancellation rate (percentage of all orders)
SELECT
    COUNT(*) AS total_orders,
    SUM(order_status = 'Cancelled') AS cancelled_orders,
    ROUND(100.0 * SUM(order_status = 'Cancelled') / NULLIF(COUNT(*), 0), 2)
        AS cancellation_rate_pct
FROM orders;

-- 7. Revenue by product category for delivered orders
SELECT pr.category,
       SUM(oi.quantity * pr.price) AS category_revenue
FROM order_items oi
JOIN products pr ON pr.product_id = oi.product_id
JOIN orders o ON o.order_id = oi.order_id
WHERE o.order_status = 'Delivered'
GROUP BY pr.category
ORDER BY category_revenue DESC;

-- 8. Payment method usage and value (delivered orders only)
SELECT p.payment_mode,
       COUNT(*) AS payment_count,
       SUM(p.amount) AS total_amount
FROM payments p
JOIN orders o ON o.order_id = p.order_id
WHERE o.order_status = 'Delivered'
GROUP BY p.payment_mode
ORDER BY total_amount DESC;

-- 9. Daily order trend
SELECT order_date, COUNT(*) AS orders_placed
FROM orders
GROUP BY order_date
ORDER BY order_date;

-- 10. Products that may need restocking (threshold is an example)
SELECT product_id, product_name, stock
FROM products
WHERE stock < 50
ORDER BY stock ASC, product_name;

-- 11. Data-quality check: orders without a payment record
SELECT o.order_id, o.order_status
FROM orders o
LEFT JOIN payments p ON p.order_id = o.order_id
WHERE p.payment_id IS NULL
ORDER BY o.order_id;

-- 12. Data-quality check: order items attached to non-delivered orders
SELECT o.order_id, o.order_status, COUNT(*) AS line_items
FROM orders o
JOIN order_items oi ON oi.order_id = o.order_id
WHERE o.order_status <> 'Delivered'
GROUP BY o.order_id, o.order_status
ORDER BY o.order_id;
